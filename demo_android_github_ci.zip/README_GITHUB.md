# Demo Android App with GitHub Actions CI

## How to build the demo APK via GitHub Actions
1. Create a new GitHub repository and push the contents of this folder to it.
2. Ensure the main branch exists (or change the workflow branch name).
3. GitHub Actions will run the `Android CI - Build Demo APK` workflow and produce an artifact `demo-apk`.
4. After the workflow finishes, go to the Actions tab and download the APK artifact.

## Notes
- This demo APK contains no native LLM. It's a fully buildable Android app that demonstrates avatar, TTS and floating UI placeholders.
- To include native libs (llama.cpp), you'd add the native source and update `app/build.gradle` to include `externalNativeBuild` and NDK; CI will need increased setup for NDK which is possible by extending the workflow.
