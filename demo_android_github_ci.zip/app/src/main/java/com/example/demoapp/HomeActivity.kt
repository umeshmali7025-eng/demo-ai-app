package com.example.demoapp
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.airbnb.lottie.LottieAnimationView
import android.widget.TextView
import android.speech.tts.TextToSpeech
import java.util.Locale

class HomeActivity : AppCompatActivity() {
    lateinit var tts: TextToSpeech
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        val tv = findViewById<TextView>(R.id.tvPrompt)
        val lottie = findViewById<LottieAnimationView>(R.id.lottieAvatar)
        tv.text = "Demo AI (no native model)\nTap to simulate"
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("hi","IN")
            }
        }
        // simple demo speak
        tv.setOnClickListener {
            val reply = "Namaste! Main aapka demo AI hoon. Yeh offline demo hai."
            tts.setPitch(1.0f)
            tts.setSpeechRate(1.0f)
            tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "demo")
            lottie.playAnimation()
        }
    }
    override fun onDestroy() {
        tts.shutdown()
        super.onDestroy()
    }
}
